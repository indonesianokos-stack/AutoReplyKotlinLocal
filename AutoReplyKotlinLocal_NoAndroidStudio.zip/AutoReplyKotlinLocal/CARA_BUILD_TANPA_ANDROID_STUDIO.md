# Cara bikin APK tanpa Android Studio

Kamu bisa build APK gratis lewat GitHub Actions. Ini cocok kalau kamu tidak punya laptop kuat atau tidak mau install Android Studio.

## Opsi paling mudah: GitHub Actions

### 1. Buat repository baru
1. Buka GitHub.
2. Buat repository baru, misalnya `AutoReplyKotlinLocal`.
3. Upload semua isi folder project ini ke repository tersebut.
   - Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.

### 2. Jalankan build APK
1. Masuk ke tab **Actions** di repository.
2. Pilih workflow **Build APK**.
3. Tekan **Run workflow**.
4. Tunggu sampai statusnya hijau/success.
5. Buka hasil workflow tersebut.
6. Download artifact bernama:

```text
AutoReplyKotlinLocal-debug-apk
```

Di dalam artifact itu ada file APK debug, biasanya bernama:

```text
app-debug.apk
```

### 3. Install di HP Android
1. Kirim `app-debug.apk` ke HP.
2. Buka file APK.
3. Izinkan install dari sumber tidak dikenal bila diminta.
4. Buka aplikasinya.
5. Tekan tombol untuk membuka pengaturan Notification Access.
6. Aktifkan akses notifikasi untuk AutoReply Lokal.

## Catatan penting

Aplikasi ini bekerja dengan membalas lewat fitur `Reply/Balas` pada notifikasi. Jadi aplikasi target harus menampilkan tombol balas di notifikasi, misalnya WhatsApp, Telegram, Signal, atau aplikasi chat lain yang mendukung inline reply.

Aplikasi ini tidak memakai server dan manifest sengaja tidak meminta permission `INTERNET`.

## Kalau build GitHub gagal

Cek tab **Actions** lalu buka log error. Error yang paling sering:

- File project tidak ter-upload lengkap.
- Folder `.github/workflows` tidak ikut ter-upload.
- Branch repository bukan `main` atau `master`; tetap bisa jalankan manual lewat **Run workflow**.
- GitHub Actions belum diaktifkan untuk repository tersebut.
