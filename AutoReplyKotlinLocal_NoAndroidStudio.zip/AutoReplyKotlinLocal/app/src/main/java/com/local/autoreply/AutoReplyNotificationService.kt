package com.local.autoreply

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class AutoReplyNotificationService : NotificationListenerService() {
    private val lastReplyAt = ConcurrentHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handleNotification(sbn)
        } catch (error: Throwable) {
            Log.e(TAG, "Gagal memproses notifikasi", error)
        }
    }

    private fun handleNotification(sbn: StatusBarNotification) {
        if (!Prefs.isEnabled(this)) return
        if (sbn.isOngoing) return

        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val allowedPackages = Prefs.allowedPackages(this)
        if (allowedPackages.isNotEmpty() && sbn.packageName !in allowedPackages) return

        val replyAction = findReplyAction(notification) ?: return
        val title = getExtraText(notification, Notification.EXTRA_TITLE)
        val text = extractNotificationText(notification)
        if (text.isBlank() && title.isBlank()) return

        if (!matchesKeyword(title, text)) return
        if (isCoolingDown(sbn.packageName, title, Prefs.cooldownMillis(this))) return

        val reply = Prefs.replyMessage(this)
        sendReply(replyAction, reply)
        markReplied(sbn.packageName, title)
    }

    private fun findReplyAction(notification: Notification): Notification.Action? {
        val actions = notification.actions ?: return null
        val actionsWithInput = actions.filter { !it.remoteInputs.isNullOrEmpty() }
        if (actionsWithInput.isEmpty()) return null

        return actionsWithInput.firstOrNull { action ->
            val label = action.title?.toString()?.lowercase(Locale.getDefault()).orEmpty()
            listOf("reply", "balas", "respond", "jawab").any { keyword -> label.contains(keyword) }
        } ?: actionsWithInput.first()
    }

    private fun sendReply(action: Notification.Action, message: String) {
        val remoteInputs = action.remoteInputs ?: return
        val results = Bundle()
        remoteInputs.forEach { input ->
            results.putCharSequence(input.resultKey, message)
        }

        val fillInIntent = Intent()
        RemoteInput.addResultsToIntent(remoteInputs, fillInIntent, results)
        action.actionIntent.send(this, 0, fillInIntent)
    }

    private fun matchesKeyword(title: String, text: String): Boolean {
        val keywords = Prefs.keywords(this)
        if (keywords.isEmpty()) return true

        val haystack = if (Prefs.matchTitle(this)) "$title $text" else text
        val normalized = haystack.lowercase(Locale.getDefault())
        return keywords.any { keyword -> normalized.contains(keyword.lowercase(Locale.getDefault())) }
    }

    private fun isCoolingDown(packageName: String, title: String, cooldownMillis: Long): Boolean {
        if (cooldownMillis <= 0L) return false
        val key = conversationKey(packageName, title)
        val previous = lastReplyAt[key] ?: return false
        return System.currentTimeMillis() - previous < cooldownMillis
    }

    private fun markReplied(packageName: String, title: String) {
        lastReplyAt[conversationKey(packageName, title)] = System.currentTimeMillis()
    }

    private fun conversationKey(packageName: String, title: String): String =
        "$packageName:${title.lowercase(Locale.getDefault()).trim()}"

    private fun extractNotificationText(notification: Notification): String {
        val parts = mutableListOf<String>()
        addIfNotBlank(parts, getExtraText(notification, Notification.EXTRA_TEXT))
        addIfNotBlank(parts, getExtraText(notification, Notification.EXTRA_BIG_TEXT))
        notification.extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.mapNotNull { it?.toString() }
            ?.forEach { addIfNotBlank(parts, it) }
        return parts.distinct().joinToString(" ")
    }

    private fun getExtraText(notification: Notification, key: String): String =
        notification.extras.getCharSequence(key)?.toString().orEmpty()

    private fun addIfNotBlank(parts: MutableList<String>, value: String) {
        if (value.isNotBlank()) parts.add(value)
    }

    companion object {
        private const val TAG = "AutoReplyService"
    }
}
