package com.local.autoreply

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE_NAME = "auto_reply_preferences"

    const val KEY_ENABLED = "enabled"
    const val KEY_REPLY_MESSAGE = "reply_message"
    const val KEY_KEYWORDS = "keywords"
    const val KEY_ALLOWED_PACKAGES = "allowed_packages"
    const val KEY_COOLDOWN_SECONDS = "cooldown_seconds"
    const val KEY_MATCH_TITLE = "match_title"

    const val DEFAULT_REPLY = "Terima kasih, pesanmu sudah diterima. Aku akan membalas nanti."
    const val DEFAULT_KEYWORDS = ""
    const val DEFAULT_PACKAGES = "com.whatsapp, com.whatsapp.w4b, org.telegram.messenger, org.thunderdog.challegram, com.google.android.apps.messaging, com.facebook.orca, com.instagram.android"
    const val DEFAULT_COOLDOWN_SECONDS = 60

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, false)

    fun replyMessage(context: Context): String =
        prefs(context).getString(KEY_REPLY_MESSAGE, DEFAULT_REPLY)?.trim().orEmpty()
            .ifBlank { DEFAULT_REPLY }

    fun keywords(context: Context): List<String> =
        prefs(context).getString(KEY_KEYWORDS, DEFAULT_KEYWORDS)
            ?.split(',')
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

    fun allowedPackages(context: Context): Set<String> =
        prefs(context).getString(KEY_ALLOWED_PACKAGES, DEFAULT_PACKAGES)
            ?.split(',')
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.toSet()
            ?: emptySet()

    fun cooldownMillis(context: Context): Long =
        (prefs(context).getInt(KEY_COOLDOWN_SECONDS, DEFAULT_COOLDOWN_SECONDS).coerceAtLeast(0) * 1000L)

    fun matchTitle(context: Context): Boolean = prefs(context).getBoolean(KEY_MATCH_TITLE, true)
}
