package com.local.autoreply

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var replyInput: EditText
    private lateinit var keywordInput: EditText
    private lateinit var packagesInput: EditText
    private lateinit var cooldownInput: EditText
    private lateinit var matchTitleSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildContentView())
        loadPreferences()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun buildContentView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        val title = TextView(this).apply {
            text = "AutoReply Lokal"
            textSize = 28f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        root.addView(TextView(this).apply {
            text = "Balas pesan otomatis dari notifikasi yang memiliki tombol Balas/Reply. Semua aturan tersimpan lokal di HP."
            textSize = 14f
            setPadding(0, dp(8), 0, dp(16))
        })

        statusView = TextView(this).apply {
            textSize = 15f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEAF3FF.toInt())
        }
        root.addView(statusView, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        enabledSwitch = Switch(this).apply { text = "Aktifkan auto-reply" }
        root.addView(enabledSwitch)

        matchTitleSwitch = Switch(this).apply {
            text = "Cocokkan keyword dengan nama pengirim/judul juga"
        }
        root.addView(matchTitleSwitch)

        replyInput = labeledEditText(root, "Pesan balasan", true)
        keywordInput = labeledEditText(root, "Keyword pemicu, pisahkan dengan koma. Kosongkan untuk balas semua pesan.", false)
        packagesInput = labeledEditText(root, "Package aplikasi yang boleh dibalas, pisahkan dengan koma. Kosongkan untuk semua aplikasi.", true)
        cooldownInput = labeledEditText(root, "Cooldown per chat dalam detik", false).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        val saveButton = Button(this).apply {
            text = "Simpan Pengaturan"
            setOnClickListener { savePreferences() }
        }
        root.addView(saveButton, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        val openSettingsButton = Button(this).apply {
            text = "Buka Izin Akses Notifikasi"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        root.addView(openSettingsButton, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        root.addView(TextView(this).apply {
            text = "Catatan: aplikasi ini tidak punya izin INTERNET. Auto-reply hanya bekerja bila aplikasi pesan menampilkan action Balas/Reply di notifikasi."
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(16), 0, 0)
        })

        return ScrollView(this).apply { addView(root) }
    }

    private fun labeledEditText(parent: LinearLayout, label: String, multiLine: Boolean): EditText {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(4))
        })
        val editText = EditText(this).apply {
            minLines = if (multiLine) 2 else 1
            maxLines = if (multiLine) 5 else 1
            inputType = if (multiLine) {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            } else {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            }
            setSingleLine(!multiLine)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        parent.addView(editText, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        return editText
    }

    private fun loadPreferences() {
        val prefs = Prefs.prefs(this)
        enabledSwitch.isChecked = prefs.getBoolean(Prefs.KEY_ENABLED, false)
        matchTitleSwitch.isChecked = prefs.getBoolean(Prefs.KEY_MATCH_TITLE, true)
        replyInput.setText(prefs.getString(Prefs.KEY_REPLY_MESSAGE, Prefs.DEFAULT_REPLY))
        keywordInput.setText(prefs.getString(Prefs.KEY_KEYWORDS, Prefs.DEFAULT_KEYWORDS))
        packagesInput.setText(prefs.getString(Prefs.KEY_ALLOWED_PACKAGES, Prefs.DEFAULT_PACKAGES))
        cooldownInput.setText(prefs.getInt(Prefs.KEY_COOLDOWN_SECONDS, Prefs.DEFAULT_COOLDOWN_SECONDS).toString())
        updatePermissionStatus()
    }

    private fun savePreferences() {
        val cooldown = cooldownInput.text.toString().toIntOrNull() ?: Prefs.DEFAULT_COOLDOWN_SECONDS
        Prefs.prefs(this).edit()
            .putBoolean(Prefs.KEY_ENABLED, enabledSwitch.isChecked)
            .putBoolean(Prefs.KEY_MATCH_TITLE, matchTitleSwitch.isChecked)
            .putString(Prefs.KEY_REPLY_MESSAGE, replyInput.text.toString().trim())
            .putString(Prefs.KEY_KEYWORDS, keywordInput.text.toString().trim())
            .putString(Prefs.KEY_ALLOWED_PACKAGES, packagesInput.text.toString().trim())
            .putInt(Prefs.KEY_COOLDOWN_SECONDS, cooldown.coerceAtLeast(0))
            .apply()
        Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        val hasAccess = isNotificationListenerEnabled()
        val isEnabled = enabledSwitch.isChecked
        statusView.text = when {
            hasAccess && isEnabled -> "Status: Siap membalas otomatis."
            hasAccess -> "Status: Izin notifikasi sudah aktif. Nyalakan switch auto-reply lalu simpan."
            else -> "Status: Belum ada izin akses notifikasi. Tekan tombol izin lalu aktifkan AutoReply Lokal Listener."
        }
        statusView.setBackgroundColor(if (hasAccess && isEnabled) 0xFFE9F7EF.toInt() else 0xFFFFF4E5.toInt())
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val expected = ComponentName(this, AutoReplyNotificationService::class.java).flattenToString()
        val enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabledListeners.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
}
