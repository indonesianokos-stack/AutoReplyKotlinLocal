# Tidak ada aturan khusus untuk versi awal.
