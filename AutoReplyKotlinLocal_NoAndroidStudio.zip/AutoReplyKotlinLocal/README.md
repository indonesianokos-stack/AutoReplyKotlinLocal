# AutoReply Lokal — Kotlin Android

Aplikasi Android sederhana seperti AutoResponder: membalas pesan otomatis secara lokal dari notifikasi yang memiliki tombol **Balas/Reply**. Tidak memakai server dan manifest sengaja tidak meminta permission `INTERNET`.

## Fitur

- Dibuat dengan Kotlin.
- Berjalan lokal melalui `NotificationListenerService`.
- Membalas lewat `RemoteInput` dari action notifikasi.
- Aturan keyword: kosong = balas semua, atau isi beberapa keyword dipisah koma.
- Filter package aplikasi: default mencakup WhatsApp, WhatsApp Business, Telegram, Google Messages, Messenger, Instagram. Kosongkan untuk semua aplikasi.
- Cooldown per nama chat/pengirim agar tidak spam.
- UI sederhana tanpa dependency AndroidX/Compose.

## Cara menjalankan di HP

1. Buka proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Jalankan ke perangkat Android fisik.
4. Buka aplikasi **AutoReply Lokal**.
5. Tekan **Buka Izin Akses Notifikasi**.
6. Aktifkan **AutoReply Lokal Listener**.
7. Kembali ke aplikasi, aktifkan switch **Aktifkan auto-reply**, lalu simpan.

## Cara membuat APK debug

Di Android Studio:

- Menu **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
- APK biasanya muncul di:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Via terminal setelah Gradle tersedia:

```bash
gradle assembleDebug
```

Atau, jika Android Studio sudah membuat Gradle Wrapper:

```bash
./gradlew assembleDebug
```

## Catatan penting

- Aplikasi hanya bisa membalas bila notifikasi punya tombol balas cepat. Jika aplikasi pesan tidak menyediakan action `RemoteInput`, auto-reply tidak bisa dikirim.
- Jangan aktifkan untuk semua aplikasi tanpa filter, karena bisa membalas notifikasi yang tidak diinginkan.
- Gunakan hanya di perangkat dan akun milik sendiri.

## Tanpa Android Studio

Kalau tidak punya Android Studio, gunakan GitHub Actions. Project ini sudah menyertakan workflow:

```text
.github/workflows/build-apk.yml
```

Ikuti panduan lengkap di:

```text
CARA_BUILD_TANPA_ANDROID_STUDIO.md
```
